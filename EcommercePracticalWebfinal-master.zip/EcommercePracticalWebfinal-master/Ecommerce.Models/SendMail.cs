﻿using MailKit.Security;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using MimeKit.Text;
using MimeKit;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using MailKit.Net.Smtp;

namespace Ecommerce.Models
{
    public static class SendMail
    {
        public static void mail(EmailCon emailCon)
        {
           
        }
    }
}
